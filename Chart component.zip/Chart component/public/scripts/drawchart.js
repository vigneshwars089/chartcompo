var Global_chart_data = {};
// console.log(Global_chart_data);
function get_data(){
    $.getJSON("Map_Data/ChartInput.json", function(jsonObj){
      // var jsonObj = {};
        for(var k in jsonObj)
        {
          Global_chart_data[k] = jsonObj[k] ;
        }
        // console.log(Global_chart_data);
  });
}


 function GeoChartDraw(){
        //document.getElementById('regions_div').style.display='block';
        //document.getElementById('piechart_div').style.display='none';
        //document.getElementById('Column_div').style.display='none';
        //document.getElementById('Histo_div').style.display='none';
        //document.getElementById('chart_div').style.display='none';

        google.charts.load('current', {'packages':['geochart']});
             google.charts.setOnLoadCallback(drawRegionsMap);

     function drawRegionsMap() {
       var data= null;
      //  $.getJSON("Map_Data/ChartInput.json", function(jsonObj){
      var jsonObj = {};
        for(var k in Global_chart_data)
        {
          jsonObj[k] = Global_chart_data[k];
        }
        // console.log(jsonObj);
         var data = google.visualization.arrayToDataTable(jsonObj['GeoData']);
         //var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));
         var options = {
              colors: ['#00FF00','#0000FF','#000000','#FFFFFF','#FF0000']
               };
           function selectHandler() {
               var selectedItem = chart.getSelection()[0];
               if (selectedItem)
               {
                   var topping = data.getValue(selectedItem.row, 1);
                   document.getElementById("myLink").innerHTML=topping;
               }
                 }
              google.visualization.events.addListener(chart, 'select', selectHandler);
               chart.draw(data, options);
              //  });
         }
   }
 function BarChartDraw(){
     //document.getElementById('chart_div').style.display='block';
     //document.getElementById('regions_div').style.display='none';
     //document.getElementById('piechart_div').style.display='none';
     //document.getElementById('Column_div').style.display='none';
     //document.getElementById('Histo_div').style.display='none';

     google.charts.load('current', {packages: ['corechart', 'bar']});
     google.charts.setOnLoadCallback(drawStacked);

     function drawStacked() {
      var options1 = {
        chartArea: {width: '50%'},
        isStacked: true,
        hAxis: {
          title: 'Country',
          minValue: 0,
          width:"200px",
          slantedText: true,

          slantedTextAngle:40
        },
        // legend:'none',
        width:'800px',
        vAxis: {
          title: 'Counts',
          height:"500px"
        },
        width: 350,
                height: 300,
                bar: {groupWidth: "40%"},
                 bars: 'vertical-align',
                 animation: {
         duration: 1000,
         easing: 'in'
     }
      };

      var data= null;
      //  $.getJSON("Map_Data/ChartInput.json", function(jsonObj){
            //  console.log(jsonObj.barData);
            var jsonObj = {};
              for(var k in Global_chart_data)
              {
                jsonObj[k] = Global_chart_data[k];
              }
          var data1 = google.visualization.arrayToDataTable(jsonObj['barData']);
          var data2 = google.visualization.arrayToDataTable(jsonObj['barData1']);
          //  var data1 = google.visualization.arrayToDataTable(jsonObj['GeoData1']);
            //  console.log(data);
              //var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
             chart.draw(data1, options1);
            //  });
    }
}
 function PieChartDraw(){
        //document.getElementById('piechart_div').style.display='block';
        //document.getElementById('regions_div').style.display='none';
        //document.getElementById('Column_div').style.display='none';
        //document.getElementById('Histo_div').style.display='none';
        //document.getElementById('chart_div').style.display='none';
        google.charts.load("current", {packages:["corechart"]});
            google.charts.setOnLoadCallback(drawChart1);
            function drawChart1() {

              // $.getJSON("Map_Data/ChartInput.json", function(jsonObj){
                  //  console.log(jsonObj.pieData);
                  var jsonObj = {};
                    for(var k in Global_chart_data)
                    {
                      jsonObj[k] = Global_chart_data[k];
                    }
              var Pieoptions = {
                title: 'Projects',
                is3D: true,

              };
              var Piedata = google.visualization.arrayToDataTable(jsonObj['pieData']);

              //var chart = new google.visualization.PieChart(document.getElementById('piechart_div'));
              chart.draw(Piedata, Pieoptions);
            // });
          }

}
function ColumnChartDraw(){
     //document.getElementById('Column_div').style.display='block';
     //document.getElementById('regions_div').style.display='none'
     //document.getElementById('Histo_div').style.display='none';
     //document.getElementById('piechart_div').style.display='none';
     //document.getElementById('chart_div').style.display='none';
     google.charts.load('current', {packages: ['corechart', 'bar']});
     google.charts.setOnLoadCallback(drawBar1);

   function drawBar1() {
      var options1 = {
        chartArea: {width: '50%'},
        hAxis: {
          title: 'Country',
          minValue: 0,
          width:"200px",
          slantedText: true,

          slantedTextAngle:40
        },
        // legend:'none',
        width:'800px',
        vAxis: {
          title: 'Counts',
          height:"500px"
        },
        width: 350,
                height: 300,
                bar: {groupWidth: "100%"},
                 bars: 'vertical-align',
                 animation: {
         duration: 1000,
         easing: 'in'
     }
      };

      var data= null;
      //  $.getJSON("Map_Data/ChartInput.json", function(jsonObj){
            //  console.log(jsonObj.barData);
            var jsonObj = {};
              for(var k in Global_chart_data)
              {
                jsonObj[k] = Global_chart_data[k];
              }
          var data1 = google.visualization.arrayToDataTable(jsonObj['barData']);
            //  console.log(data);
              //var chart = new google.visualization.ColumnChart(document.getElementById('Column_div'));
             chart.draw(data1, options1);
            //  });
    }
}
function HistoChartDraw(){
     //document.getElementById('Histo_div').style.display='block';
     //document.getElementById('regions_div').style.display='none'
     //document.getElementById('Column_div').style.display='none'
     //document.getElementById('chart_div').style.display='none';
     //document.getElementById('piechart_div').style.display='none'
     google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
    //  $.getJSON("Map_Data/ChartInput.json", function(jsonObj){2
    var jsonObj = {};
      for(var k in Global_chart_data)
      {
        jsonObj[k] = Global_chart_data[k];
      }
        var Histooptions = {
          pieSliceText: 'label',
          slices: {  4: {offset: 0.2},
                    12: {offset: 0.3},
                    14: {offset: 0.4},
                    15: {offset: 0.5},
          },
        };

        var Histodata = google.visualization.arrayToDataTable(jsonObj['histoData']);
              //var chart = new google.visualization.PieChart(document.getElementById('Histo_div'));
              chart.draw(Histodata, Histooptions);
      // });
    }

}
