function viewchart(){
  alert("working");
  };
