function viewchart(){
  console.log("enter");
  var radioBtn = $('<div id="mychart" style="margin-left: 20%;margin-top: 4%;"><label><input type="radio" class="option-input radio" name="example" value="Pie Chart"/>Radio option</label><label><input type="radio" class="option-input radio" name="example" />Radio option</label><label><input type="radio" class="option-input radio" name="example" />Radio option</label></div>');
     radioBtn.appendTo('#Chart_div');
};

// $('#mychart input').on('change', function() {
//    alert($('input[name="myRadio"]:checked', '#myForm').val());
// });

var Global_chart_data = {};
// console.log(Global_chart_data);
function get_data(){
    $.getJSON("/ChartInput.json", function(jsonObj){
      // var jsonObj = {};
        for(var k in jsonObj)
        {
          Global_chart_data[k] = jsonObj[k] ;
        }
        console.log(Global_chart_data);
  });
}
var ChartName;
function drawchart(ChartName)
{























//---------------------------------------------STACKED CHART XY Y
// document.getElementById('Stackchart_div').style.display='block';
// google.charts.load("current", {packages:['corechart']});
// google.charts.setOnLoadCallback(drawChart);
//   function drawChart() {
//
//
//
//      var jsonObj = {};
//                   for(var k in Global_chart_data)
//                    {
//                     jsonObj[k] = Global_chart_data[k];
//               }
//              console.log(jsonObj.pieData);
//
//     var Columndata = google.visualization.arrayToDataTable(jsonObj['ThirdData']);
//
//
//     var view = new google.visualization.DataView(Columndata);
//     view.setColumns([0, 1,
//                      { calc: "stringify",
//                        sourceColumn: 1,
//                        type: "string",
//                        role: "annotation" },
//                      2]);
//
//     var options = {
//     width:400,
//       height: 300,
//       legend: { position: 'top', maxLines: 3 },
//       bar: { groupWidth: '50%' },
//       isStacked: true,
//     };
//     var chart = new google.visualization.ColumnChart(document.getElementById("Stackchart_div"));
//     chart.draw(view, options);
// }































  //----------------------------------------------Area GRAPH X Y Y
  // document.getElementById('Areachart_div').style.display='block';
  // google.charts.load('current', {'packages':['corechart']});
  // google.charts.setOnLoadCallback(drawChart);
  //
  // function drawChart() {
  //   var jsonObj = {};
  //                for(var k in Global_chart_data)
  //                 {
  //                  jsonObj[k] = Global_chart_data[k];
  //            }
  //           console.log(jsonObj.pieData);
  //
  //
  //   var options = {
  //     title: 'Company Performance',
  //     hAxis: {title: 'Year',  titleTextStyle: {color: '#333'}},
  //     vAxis: {minValue: 0}
  //   };
  //     var AreaData = google.visualization.arrayToDataTable(jsonObj['areaData']);
  //
  //   var chart = new google.visualization.AreaChart(document.getElementById('Areachart_div'));
  //   chart.draw(AreaData, options);
  // }



























  //--------------------------------------------COLUMN CHART
  // document.getElementById('Column_div').style.display='block';
  //
  // google.charts.load('current', {'packages':['bar']});
  // google.charts.setOnLoadCallback(drawStuff);
  //
  // function drawStuff() {
  //   // var data = new google.visualization.arrayToDataTable([
  //   //   ['Move', 'Percentage'],
  //   //   ["King's pawn (e4)", 44],
  //   //   ["Queen's pawn (d4)", 31],
  //   //   ["Knight to King 3 (Nf3)", 12],
  //   //   ["Queen's bishop pawn (c4)", 10],
  //   //   ['Other', 3]
  //   // ]);
  //             var jsonObj = {};
  //               for(var k in Global_chart_data)
  //               {
  //                 jsonObj[k] = Global_chart_data[k];
  //               }
  //               console.log(jsonObj.pieData);
  //   var options = {
  //     width: 300,
  //     legend: { position: 'none' },
  //     chart: {
  //       title: 'Chess opening moves',
  //       subtitle: 'popularity by percentage' },
  //     axes: {
  //       x: {
  //         0: { side: 'top', label: 'White to move'} // Top x-axis.
  //       }
  //     },
  //     bar: { groupWidth: "60%" }
  //   };
  //   var Columndata = google.visualization.arrayToDataTable(jsonObj['columnData']);
  //
  //   var chart = new google.charts.Bar(document.getElementById('Column_div'));
  //   // Convert the Classic options to Material options.
  //   chart.draw(Columndata, google.charts.Bar.convertOptions(options));
  // };






















//--------------------------------------------------PIE CHART
  // document.getElementById('piechart_div').style.display='block';
  // google.charts.load("current", {packages:["corechart"]});
  //     google.charts.setOnLoadCallback(drawChart1);
  //     function drawChart1() {
  //
  //       // $.getJSON("Map_Data/ChartInput.json", function(jsonObj){
  //           // console.log(jsonObj.pieData);
  //           var jsonObj = {};
  //             for(var k in Global_chart_data)
  //             {
  //               jsonObj[k] = Global_chart_data[k];
  //             }
  //             console.log(jsonObj.pieData);
  //
  //       var Pieoptions = {
  //         title: 'Projects',
  //         is3D: true,
  //
  //       };
  //       var Piedata = google.visualization.arrayToDataTable(jsonObj['pieData']);
  //
  //       var chart = new google.visualization.PieChart(document.getElementById('piechart_div'));
  //       chart.draw(Piedata, Pieoptions);
  //     // });
  //   }




  //------------------------------------------------HISTO CHART Range
  // google.charts.load("current", {packages:["corechart"]});
  //     google.charts.setOnLoadCallback(drawChart);
  //     function drawChart() {
  //       // var data = google.visualization.arrayToDataTable([
  //       //   ['Dinosaur', 'Length'],
  //       //   ['Acrocanthosaurus (top-spined lizard)', 12.2],
  //       //   ['Albertosaurus (Alberta lizard)', 9.1],
  //       //   ['Allosaurus (other lizard)', 12.2],
  //       //   ['Apatosaurus (deceptive lizard)', 22.9],
  //       //   ['Archaeopteryx (ancient wing)', 0.9],
  //       //   ['Argentinosaurus (Argentina lizard)', 36.6],
  //       //   ['Baryonyx (heavy claws)', 9.1],
  //       //   ['Brachiosaurus (arm lizard)', 30.5],
  //       //   ['Ceratosaurus (horned lizard)', 6.1],
  //       //   ['Coelophysis (hollow form)', 2.7],
  //       //   ['Compsognathus (elegant jaw)', 0.9],
  //       //   ['Deinonychus (terrible claw)', 2.7],
  //       //   ['Diplodocus (double beam)', 27.1],
  //       //   ['Dromicelomimus (emu mimic)', 3.4],
  //       //   ['Gallimimus (fowl mimic)', 5.5],
  //       //   ['Mamenchisaurus (Mamenchi lizard)', 21.0],
  //       //   ['Megalosaurus (big lizard)', 7.9],
  //       //   ['Microvenator (small hunter)', 1.2],
  //       //   ['Ornithomimus (bird mimic)', 4.6],
  //       //   ['Oviraptor (egg robber)', 1.5],
  //       //   ['Plateosaurus (flat lizard)', 7.9],
  //       //   ['Sauronithoides (narrow-clawed lizard)', 2.0],
  //       //   ['Seismosaurus (tremor lizard)', 45.7],
  //       //   ['Spinosaurus (spiny lizard)', 12.2],
  //       //   ['Supersaurus (super lizard)', 30.5],
  //       //   ['Tyrannosaurus (tyrant lizard)', 15.2],
  //       //   ['Ultrasaurus (ultra lizard)', 30.5],
  //       //   ['Velociraptor (swift robber)', 1.8]]);
  //
  //       var options = {
  //         title: 'Lengths of dinosaurs, in meters',
  //         legend: { position: 'none' },
  //       };
  //
  //       var chart = new google.visualization.Histogram(document.getElementById('chart_div'));
  //       chart.draw(data, options);
  //     }









//-------------------------------------------------LINE CHART xy y
  // google.charts.load('current', {'packages':['corechart']});
  //  google.charts.setOnLoadCallback(drawChart);
  //
  //  function drawChart() {
  //    var data = google.visualization.arrayToDataTable([
  //      ['Year', 'Sales', 'Expenses'],
  //      ['2004',  1000,      400],
  //      ['2005',  1170,      460],
  //      ['2006',  660,       1120],
  //      ['2007',  1030,      540]
  //    ]);
  //
  //    var options = {
  //      title: 'Company Performance',
  //      curveType: 'function',
  //      legend: { position: 'bottom' }
  //    };
  //
  //    var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));
  //
  //    chart.draw(data, options);
  //  }



//------------------------------------------------Calendar Chart XY
//   google.charts.load("current", {packages:["calendar"]});
//    google.charts.setOnLoadCallback(drawChart);
//
// function drawChart() {
//     // var dataTable = new google.visualization.DataTable();
//     // dataTable.addColumn({ type: 'date', id: 'Date' });
//     // dataTable.addColumn({ type: 'number', id: 'Won/Loss' });
//     // dataTable.addRows([
//     //    [ new Date(2012, 3, 13), 37032 ],
//     //    [ new Date(2012, 3, 14), 38024 ],
//     //    [ new Date(2012, 3, 15), 38024 ],
//     //    [ new Date(2012, 3, 16), 38108 ],
//     //    [ new Date(2012, 3, 17), 38229 ],
//     //    // Many rows omitted for brevity.
//     //    [ new Date(2013, 9, 4), 38177 ],
//     //    [ new Date(2013, 9, 5), 38705 ],
//     //    [ new Date(2013, 9, 12), 38210 ],
//     //    [ new Date(2013, 9, 13), 38029 ],
//     //    [ new Date(2013, 9, 19), 38823 ],
//     //    [ new Date(2013, 9, 23), 38345 ],
//     //    [ new Date(2013, 9, 24), 38436 ],
//     //    [ new Date(2013, 9, 30), 38447 ]
//     //  ]);
//
//     var chart = new google.visualization.Calendar(document.getElementById('calendar_basic'));
//
//     var options = {
//       title: "Red Sox Attendance",
//       height: 350,
//     };
//
//     chart.draw(dataTable, options);
// }




//----------------------------------------------candle Chart
// google.charts.load('current', {'packages':['corechart']});
//     google.charts.setOnLoadCallback(drawChart);
//     function drawChart() {
//       // var data = google.visualization.arrayToDataTable([
//       //   ['Mon', 28, 28, 38, 38],
//       //   ['Tue', 38, 38, 55, 55],
//       //   ['Wed', 55, 55, 77, 77],
//       //   ['Thu', 77, 77, 66, 66],
//       //   ['Fri', 66, 66, 22, 22]
//         // Treat the first row as data.
//       ], true);
//
//       var options = {
//         legend: 'none',
//         bar: { groupWidth: '100%' }, // Remove space between bars.
//         candlestick: {
//           fallingColor: { strokeWidth: 0, fill: '#a52714' }, // red
//           risingColor: { strokeWidth: 0, fill: '#0f9d58' }   // green
//         }
//       };
//
//       var chart = new google.visualization.CandlestickChart(document.getElementById('chart_div'));
//       chart.draw(data, options);
//     }




//-------------------------------------------GANTT CHART
// google.charts.load('current', {'packages':['gantt']});
//     google.charts.setOnLoadCallback(drawChart);
//
//     function daysToMilliseconds(days) {
//       return days * 24 * 60 * 60 * 1000;
//     }
//
//     function drawChart() {
//
//       // var data = new google.visualization.DataTable();
//       // data.addColumn('string', 'Task ID');
//       // data.addColumn('string', 'Task Name');
//       // data.addColumn('date', 'Start Date');
//       // data.addColumn('date', 'End Date');
//       // data.addColumn('number', 'Duration');
//       // data.addColumn('number', 'Percent Complete');
//       // data.addColumn('string', 'Dependencies');
//       //
//       // data.addRows([
//       //   ['Research', 'Find sources',
//       //    new Date(2015, 0, 1), new Date(2015, 0, 5), null,  100,  null],
//       //   ['Write', 'Write paper',
//       //    null, new Date(2015, 0, 9), daysToMilliseconds(3), 25, 'Research,Outline'],
//       //   ['Cite', 'Create bibliography',
//       //    null, new Date(2015, 0, 7), daysToMilliseconds(1), 20, 'Research'],
//       //   ['Complete', 'Hand in paper',
//       //    null, new Date(2015, 0, 10), daysToMilliseconds(1), 0, 'Cite,Write'],
//       //   ['Outline', 'Outline paper',
//       //    null, new Date(2015, 0, 6), daysToMilliseconds(1), 100, 'Research']
//       // ]);
//
//       var options = {
//         height: 275
//       };
//
//       var chart = new google.visualization.Gantt(document.getElementById('chart_div'));
//
//       chart.draw(data, options);
//     }






   }
