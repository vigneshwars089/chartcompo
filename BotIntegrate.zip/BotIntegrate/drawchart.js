// var map = new google.maps.Map(document.getElementById('map'), {
//   zoom: 1,
//   center: new google.maps.LatLng(0,0),
//   mapTypeId: google.maps.MapTypeId.ROADMAP
// });
// var markers = [];
// var infowindow = new google.maps.InfoWindow();
// var marker, i;
//
// // map.style.visibility='hidden';
//
//
//
//
// function currentLocation(){
//   document.getElementById('regions_div').style.display='none';
// document.getElementById('map').style.display='block';
//     if (navigator.geolocation)
//     {
//       navigator.geolocation.getCurrentPosition(function(position) {
//           var pos = {
//             lat: position.coords.latitude,
//             lng: position.coords.longitude
//           };
//
//           infowindow.setPosition(pos);
//
//           var map = new google.maps.Map(document.getElementById('map'), {
//             zoom: 6,
//             center: new google.maps.LatLng(position.coords.latitude,position.coords.longitude),
//             mapTypeId: google.maps.MapTypeId.ROADMAP
//           });
//
//           marker = new google.maps.Marker({
//             map: map,
//             draggable: false,
//             animation: google.maps.Animation.DROP,
//             position: new google.maps.LatLng(position.coords.latitude, position.coords.longitude),
//           });
//           google.maps.event.addListener(marker, 'click', (function(marker, i) {
//             return function() {
//               infowindow.setContent("You are here");
//               infowindow.open(map, marker);
//             }
//           })(marker, i));
//
//           google.maps.event.addListener(marker, 'click', function(event) {
//             geocoder.geocode({
//               'latLng': event.latLng
//             }, function(results, status) {
//               if (status == google.maps.GeocoderStatus.OK) {
//                 if (results[0]) {
//                   // alert(results[0].formatted_address);
//                       infowindow.setContent(results[0].formatted_address);
//                       infowindow.open(map, marker);
//                 }
//               }
//             });
//           });
//
//           google.maps.event.addListener(marker, 'mouseout', (function(marker, i) {
//             return function() {
//               infowindow.close(map, marker);
//             }
//           })(marker, i));
//           //marker.addListener('click', toggleBounce);
//           // infowindow.open(map);
//           map.setCenter(pos);
//           }, function() {
//             handleLocationError(true, infowindow, map.getCenter());
//       }, function(geoOptions)
//       {
//          enableHighAccuracy: true
//       });
//     }
//     else
//     {
//       // Browser doesn't support Geolocation
//       handleLocationError(false, infowindow, map.getCenter());
//       return 5;
//     }
//   }










//--code to load the geochart
// google.charts.load('current', {'packages':['geochart']});
//      google.charts.setOnLoadCallback(drawRegionsMap);
//
//      function drawRegionsMap() {
//
//       var data= null;
//
//
//
//     //    var options = {
//     //  colors: ['#00FF00','#0000FF','#000000','#FFFFFF','#FF0000']
//     //    };
//
//       //  var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));
//
//        $.getJSON("./ChartInput.json", function(jsonObj){
//              console.log(jsonObj.GeoData);
//           var data = google.visualization.arrayToDataTable(jsonObj['GeoData']);
//           // var data1 = google.visualization.arrayToDataTable(jsonObj['GeoData1']);
//              console.log(data);
//             var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));
//              var options = {
//
//             colors: ['#00FF00','#0000FF','#000000','#FFFFFF','#FF0000']
//              };
//              function selectHandler() {
//                      var selectedItem = chart.getSelection()[0];
//                      if (selectedItem) {
//                        var topping = data.getValue(selectedItem.row, 1);
//                     //   alert('The user selected ' + topping);
//                        document.getElementById("myLink").innerHTML=topping;
//                      }
//                    }
//                     google.visualization.events.addListener(chart, 'select', selectHandler);
//              chart.draw(data, options);
//           //    setInterval(function() {
//           // //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
//           //        chart.draw(data1, options);
//           //     }, 5000);
//           //     setInterval(function() {
//           //  //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
//           //         chart.draw(data, options);
//           //      }, 2000);
//
//          //    var locations = jsonObj['points'];
//
//            //  for (i = 0; i < locations.length; i++) {
//            //  marker = new google.maps.Marker({
//              //      position: new google.maps.LatLng(locations[i][1], locations[i][2]),
//                    // title: locations[]
//                //    icon: {
//                  //          url: '/images_map/map_pin.png'
//                    //      },
//                  //  title: (locations[i][0]).toString(),
//              //      map: map
//              });
//       // chart.draw(data, options);
//       //  setInterval(function() {
//       //    data.setValue(0, 1, 140 + Math.round(60 * Math.random()));
//       //    chart.draw(data, options);
//       //  }, 1300);
//       //  setInterval(function() {
//       //    data.setValue(1, 1, 140 + Math.round(60 * Math.random()));
//       //    chart.draw(data, options);
//       //  }, 1300);
//       //  setInterval(function() {
//       //    data.setValue(2, 1, 160 + Math.round(20 * Math.random()));
//       //    chart.draw(data, options);
//       //  }, 1300);
//       //  setInterval(function() {
//       //    data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
//       //    chart.draw(data, options);
//       //  }, 1300);
//       //  setInterval(function() {
//       //    data.setValue(4, 1, 160 + Math.round(20 * Math.random()));
//       //    chart.draw(data, options);
//       //  }, 1300);
//       //  setInterval(function() {
//       //    data.setValue(5, 1, 160 + Math.round(20 * Math.random()));
//       //    chart.draw(data, options);
//       //  }, 1300);
//      }


//---code to load the stackedChart


//-----------------------------------------------------------load pie chart


      //-----------------------------------------------------------load Column chart
  //     google.charts.load('current', {'packages':['bar']});
  //     google.charts.setOnLoadCallback(drawStuff);
  //
  //     function drawStuff() {
  // $.getJSON("./ChartInput.json", function(jsonObj){
  //       var columnoptions = {
  //         width: 600,
  //
  //
  //               //  title: 'Population of Largest U.S. Cities',
  //                 chartArea: {width: '50%'},
  //                 isStacked: true,
  //                 hAxis: {
  //                   title: 'Country',
  //                   minValue: 0,
  //                   width:"200px",
  //                   slantedTextAngle:70
  //                 },
  //                 width:'900px',
  //                 vAxis: {
  //                   title: 'Counts',
  //                   height:"500px"
  //                 },
  //                 width: 500,
  //                         height: 450,
  //                         bar: {groupWidth: "50%"},
  //                          bars: 'vertical-align',
  //                          animation: {
  //                  duration: 1000,
  //                  easing: 'in'
  //              },
  //         // chart: {
  //         //   title: 'Nearby galaxies',
  //         //   //subtitle: 'distance on the left, brightness on the right'
  //         // },
  //         bars: 'horizontal', // Required for Material Bar Charts.
  //         // series: {
  //         //   0: { axis: 'distance' }, // Bind series 0 to an axis named 'distance'.
  //         //   1: { axis: 'brightness' } // Bind series 1 to an axis named 'brightness'.
  //         // },
  //         // axes: {
  //         //   x: {
  //         //   //  distance: {label: 'parsecs'}, // Bottom x-axis.
  //         //   //  brightness: {side: 'top', label: 'apparent magnitude'} // Top x-axis.
  //         //   }
  //         // }
  //       };
  //
  //     var ColumnData = new google.visualization.arrayToDataTable([jsonObj['columnData']]);
  //     var chart = new google.charts.Bar(document.getElementById('Column_div'));
  //     chart.draw(ColumnData, columnoptions);
  //   });
  //   }


      //-----------------------------------------------------------load Histogram chart

  //     google.charts.load("current", {packages:["corechart"]});
  //    google.charts.setOnLoadCallback(drawChart);
  //    function drawChart() {
  //        $.getJSON("./ChartInput.json", function(jsonObj){
  //
  //       var Histooptions = {
  //   title: 'Approximating Normal Distribution',
  // //  legend: { position: 'none' },
  //   colors: ['#4285F4'],
  //
  //   chartArea: { width: 401 },
  //   // hAxis: {
  //   //   ticks: [-1, -0.75, -0.5, -0.25, 0, 0.25, 0.5, 0.75, 1]
  //   // },
  //   bar: { gap: 0 },
  //
  //   histogram: {
  //     bucketSize: 0.02,
  //     maxNumBuckets: 200,
  //     minValue: -1,
  //     maxValue: 1
  //   }
  // };
  //
  // var Histodata = google.visualization.arrayToDataTable(jsonObj['histoData']);
  //       var chart = new google.visualization.Histogram(document.getElementById('Histo_div'));
  //       chart.draw(Histodata, Histooptions);
  //     });
  //   }


   function GeoChartDraw(){
        document.getElementById('regions_div').style.display='block';
        document.getElementById('piechart_div').style.display='none';
        document.getElementById('Column_div').style.display='none';
        document.getElementById('Histo_div').style.display='none';
        document.getElementById('chart_div').style.display='none';

        google.charts.load('current', {'packages':['geochart']});
             google.charts.setOnLoadCallback(drawRegionsMap);

             function drawRegionsMap() {

              var data= null;



            //    var options = {
            //  colors: ['#00FF00','#0000FF','#000000','#FFFFFF','#FF0000']
            //    };

              //  var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));

               $.getJSON("./ChartInput.json", function(jsonObj){
                     console.log(jsonObj.GeoData);
                  var data = google.visualization.arrayToDataTable(jsonObj['GeoData']);
                  // var data1 = google.visualization.arrayToDataTable(jsonObj['GeoData1']);
                     console.log(data);
                    var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));
                     var options = {

                    colors: ['#00FF00','#0000FF','#000000','#FFFFFF','#FF0000']
                     };
                     function selectHandler() {
                             var selectedItem = chart.getSelection()[0];
                             if (selectedItem) {
                               var topping = data.getValue(selectedItem.row, 1);
                            //   alert('The user selected ' + topping);
                               document.getElementById("myLink").innerHTML=topping;
                             }
                           }
                            google.visualization.events.addListener(chart, 'select', selectHandler);
                     chart.draw(data, options);
                  //    setInterval(function() {
                  // //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
                  //        chart.draw(data1, options);
                  //     }, 5000);
                  //     setInterval(function() {
                  //  //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
                  //         chart.draw(data, options);
                  //      }, 2000);

                 //    var locations = jsonObj['points'];

                   //  for (i = 0; i < locations.length; i++) {
                   //  marker = new google.maps.Marker({
                     //      position: new google.maps.LatLng(locations[i][1], locations[i][2]),
                           // title: locations[]
                       //    icon: {
                         //          url: '/images_map/map_pin.png'
                           //      },
                         //  title: (locations[i][0]).toString(),
                     //      map: map
                     });
              // chart.draw(data, options);
              //  setInterval(function() {
              //    data.setValue(0, 1, 140 + Math.round(60 * Math.random()));
              //    chart.draw(data, options);
              //  }, 1300);
              //  setInterval(function() {
              //    data.setValue(1, 1, 140 + Math.round(60 * Math.random()));
              //    chart.draw(data, options);
              //  }, 1300);
              //  setInterval(function() {
              //    data.setValue(2, 1, 160 + Math.round(20 * Math.random()));
              //    chart.draw(data, options);
              //  }, 1300);
              //  setInterval(function() {
              //    data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
              //    chart.draw(data, options);
              //  }, 1300);
              //  setInterval(function() {
              //    data.setValue(4, 1, 160 + Math.round(20 * Math.random()));
              //    chart.draw(data, options);
              //  }, 1300);
              //  setInterval(function() {
              //    data.setValue(5, 1, 160 + Math.round(20 * Math.random()));
              //    chart.draw(data, options);
              //  }, 1300);
             }
   }
   function BarChartDraw(){
     document.getElementById('chart_div').style.display='block';
     document.getElementById('regions_div').style.display='none';
     document.getElementById('piechart_div').style.display='none';
     document.getElementById('Column_div').style.display='none';
     document.getElementById('Histo_div').style.display='none';

     google.charts.load('current', {packages: ['corechart', 'bar']});
google.charts.setOnLoadCallback(drawStacked);

function drawStacked() {
      // var data = google.visualization.arrayToDataTable([
      //   ['City', '2010 Population', '2000 Population'],
      //   ['New York City, NY', 8175000, 8008000],
      //   ['Los Angeles, CA', 3792000, 3694000],
      //   ['Chicago, IL', 2695000, 2896000],
      //   ['Houston, TX', 2099000, 1953000],
      //   ['Philadelphia, PA', 1526000, 1517000]
      // ]);

      var options1 = {
      //  title: 'Population of Largest U.S. Cities',
        chartArea: {width: '50%'},
        isStacked: true,
        hAxis: {
          title: 'Country',
          minValue: 0,
          width:"200px",
          slantedText: true,

          slantedTextAngle:40
        },
        legend:'none',
        width:'800px',
        vAxis: {
          title: 'Counts',
          height:"500px"
        },
        width: 350,
                height: 300,
                bar: {groupWidth: "40%"},
                 bars: 'vertical-align',
                 animation: {
         duration: 1000,
         easing: 'in'
     }
              //  legend: { position: "none" }
      };

      var data= null;



    //   var options = {};

    //   var chart = new google.visualization.GeoChart(document.getElementById('chart_div'));

       $.getJSON("./ChartInput.json", function(jsonObj){
             console.log(jsonObj.barData);
          var data1 = google.visualization.arrayToDataTable(jsonObj['barData']);
          var data2 = google.visualization.arrayToDataTable(jsonObj['barData1']);
          //  var data1 = google.visualization.arrayToDataTable(jsonObj['GeoData1']);
             console.log(data);
              var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));


             chart.draw(data1, options1);
            //     setInterval(function() {
            //  //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
            //         chart.draw(data1, options1);
            //      }, 2000);
            //      setInterval(function() {
            //   //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
            //          chart.draw(data2, options1);
            //       }, 4000);
          //    setInterval(function() {
          // //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
          //        chart.draw(data1, options);
          //     }, 5000);
          //     setInterval(function() {
          //  //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
          //         chart.draw(data, options);
          //      }, 2000);

         //    var locations = jsonObj['points'];

           //  for (i = 0; i < locations.length; i++) {
           //  marker = new google.maps.Marker({
             //      position: new google.maps.LatLng(locations[i][1], locations[i][2]),
                   // title: locations[]
               //    icon: {
                 //          url: '/images_map/map_pin.png'
                   //      },
                 //  title: (locations[i][0]).toString(),
             //      map: map
             });

    //  var chart = new google.visualization.BarChart(document.getElementById('chart_div'));
    //  chart.draw(data, options);
    }


   }
   function PieChartDraw(){
        document.getElementById('piechart_div').style.display='block';
        document.getElementById('regions_div').style.display='none';
        document.getElementById('Column_div').style.display='none';
        document.getElementById('Histo_div').style.display='none';
        document.getElementById('chart_div').style.display='none';
        google.charts.load("current", {packages:["corechart"]});
            google.charts.setOnLoadCallback(drawChart1);
            function drawChart1() {

              $.getJSON("./ChartInput.json", function(jsonObj){
                  //  console.log(jsonObj.pieData);

              var Pieoptions = {
                title: 'Projects',
                is3D: true,

              };
              var Piedata = google.visualization.arrayToDataTable(jsonObj['pieData']);

              var chart = new google.visualization.PieChart(document.getElementById('piechart_div'));
              chart.draw(Piedata, Pieoptions);
            });
          }

   }
   function ColumnChartDraw(){
     document.getElementById('Column_div').style.display='block';
     document.getElementById('regions_div').style.display='none'
     document.getElementById('Histo_div').style.display='none';
     document.getElementById('piechart_div').style.display='none';
     document.getElementById('chart_div').style.display='none';
     google.charts.load('current', {packages: ['corechart', 'bar']});
   google.charts.setOnLoadCallback(drawBar1);

   function drawBar1() {
      // var data = google.visualization.arrayToDataTable([
      //   ['City', '2010 Population', '2000 Population'],
      //   ['New York City, NY', 8175000, 8008000],
      //   ['Los Angeles, CA', 3792000, 3694000],
      //   ['Chicago, IL', 2695000, 2896000],
      //   ['Houston, TX', 2099000, 1953000],
      //   ['Philadelphia, PA', 1526000, 1517000]
      // ]);

      var options1 = {
      //  title: 'Population of Largest U.S. Cities',
        chartArea: {width: '50%'},
        hAxis: {
          title: 'Country',
          minValue: 0,
          width:"200px",
          slantedText: true,

          slantedTextAngle:40
        },
        legend:'none',
        width:'800px',
        vAxis: {
          title: 'Counts',
          height:"500px"
        },
        width: 350,
                height: 300,
                bar: {groupWidth: "50%"},
                 bars: 'vertical-align',
                 animation: {
         duration: 1000,
         easing: 'in'
     }
              //  legend: { position: "none" }
      };

      var data= null;



    //   var options = {};

    //   var chart = new google.visualization.GeoChart(document.getElementById('chart_div'));

       $.getJSON("./ChartInput.json", function(jsonObj){
             console.log(jsonObj.barData);
          var data1 = google.visualization.arrayToDataTable(jsonObj['barData']);
       //   var data2 = google.visualization.arrayToDataTable(jsonObj['barData1']);
          //  var data1 = google.visualization.arrayToDataTable(jsonObj['GeoData1']);
             console.log(data);
              var chart = new google.visualization.ColumnChart(document.getElementById('Column_div'));


             chart.draw(data1, options1);

          //    setInterval(function() {
          // //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
          //        chart.draw(data1, options);
          //     }, 5000);
          //     setInterval(function() {
          //  //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
          //         chart.draw(data, options);
          //      }, 2000);

         //    var locations = jsonObj['points'];

           //  for (i = 0; i < locations.length; i++) {
           //  marker = new google.maps.Marker({
             //      position: new google.maps.LatLng(locations[i][1], locations[i][2]),
                   // title: locations[]
               //    icon: {
                 //          url: '/images_map/map_pin.png'
                   //      },
                 //  title: (locations[i][0]).toString(),
             //      map: map
             });

    //  var chart = new google.visualization.BarChart(document.getElementById('chart_div'));
    //  chart.draw(data, options);
    }


   }
   function HistoChartDraw(){
     document.getElementById('Histo_div').style.display='block';
     document.getElementById('regions_div').style.display='none'
     document.getElementById('Column_div').style.display='none'
     document.getElementById('chart_div').style.display='none';
     document.getElementById('piechart_div').style.display='none'
     google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
     //   var data = google.visualization.arrayToDataTable(jsonObj['histoData']);
     $.getJSON("./ChartInput.json", function(jsonObj){

        var Histooptions = {
        //  title: 'Indian Language Use',
      //    legend: 'none',
          pieSliceText: 'label',
          slices: {  4: {offset: 0.2},
                    12: {offset: 0.3},
                    14: {offset: 0.4},
                    15: {offset: 0.5},
          },
        };

        var Histodata = google.visualization.arrayToDataTable(jsonObj['histoData']);
              var chart = new google.visualization.PieChart(document.getElementById('Histo_div'));
              chart.draw(Histodata, Histooptions);
      });
    }

   }

    //  function GeoChartDraw(){
    //    if(document.getElementById('regions_div').style.display=='block')
    //       document.getElementById('regions_div').style.display='none'
    //       else
    //       document.getElementById('regions_div').style.display='block';
     //
    //  }
    //  function BarChartDraw(){
    //    if(document.getElementById('chart_div').style.display=='block')
    //    document.getElementById('chart_div').style.display='none'
    //    else
    //    document.getElementById('chart_div').style.display='block';
     //
    //  }
    //  function PieChartDraw(){
    //    if(document.getElementById('piechart_div').style.display=='block')
    //       document.getElementById('piechart_div').style.display='none'
    //       else
    //       document.getElementById('piechart_div').style.display='block';
     //
    //  }
    //  function ColumnChartDraw(){
    //    if(document.getElementById('Column_div').style.display=='block')
    //    document.getElementById('Column_div').style.display='none'
    //    else
    //    document.getElementById('Column_div').style.display='block';
     //
    //  }
    //  function HistoChartDraw(){
    //    if(document.getElementById('Histo_div').style.display=='block')
    //    document.getElementById('Histo_div').style.display='none'
    //    else
    //    document.getElementById('Histo_div').style.display='block';
     //
    //  }






    //--function to load the current map location
